==================================================================================================
    Modeling and Simulation of Mechatronic Systems M - Mechatronics Systems Modeling and Control M
==================================================================================================
Santoro Luca, 0001005415

Professor: Alessandro Macchelli   Tutor: Marco Borghesi   
==================================================================================================
         UR5 robotic arm model with Harmonic Drive actuation system               
==================================================================================================

In this project, Harmonic drive is modelled and applied on UR5 robot manipulator.
As first step run the main.m file, then the simulink model