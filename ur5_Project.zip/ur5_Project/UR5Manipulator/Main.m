%{
==================================================================================================
    Modeling and Simulation of Mechatronic Systems M - Mechatronics Systems Modeling and Control M
==================================================================================================
Santoro Luca, 0001005415

Professor: Alessandro Macchelli   Tutor: Marco Borghesi   
==================================================================================================
         UR5 robotic arm model with Harmonic Drive actuation system               
==================================================================================================
%}


clc; clear all; close all;

mdl_ur5;

%%%%%%%%%%%%%%%%%%

% % Define inertial parameters for each link
I1 = [0.0067 0 0; 0 0.0064 0; 0 0 0.0067];
I2 = [0.0149 0 0; 0 0.3564 0; 0 0 0.3553];
I3 = [0.0025 0 0.0034; 0 0.0551 0; 0.0034 0 0.0546];
I4 = [0.0012 0 0; 0 0.0012 0; 0 0 0.0009];
I5 = [0.0012 0 0; 0 0.0012 0; 0 0 0.0009];
I6 = [0.0001 0 0; 0 0.0001 0; 0 0 0.0001];

% Creazione della matrice 3x3x6 contenente i tensori di inerzia
inertia_data = zeros(3, 3, 6);
       
% Assegnazione dei tensori di inerzia alla matrice tridimensionale
inertia_data(:, :, 1) = I1;
inertia_data(:, :, 2) = I2;
inertia_data(:, :, 3) = I3;
inertia_data(:, :, 4) = I4;
inertia_data(:, :, 5) = I5;
inertia_data(:, :, 6) = I6;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Define Jm values for each link (motor inertia)
%Jm_values = [1.8e-8, 1.8e-8, 1.8e-8, 2.07e-5, 2.07e-5, 2.07e-5]; % Jm values for each link
Jm_values = [0.091e-4, 0.091e-4, 0.091e-4, 0.091e-4, 0.091e-4, 0.091e-4];
Tc_values = [7.4e-2, 7.4e-2, 7.4e-2, 3.4e-2, 3.4e-2, 3.4e-2]; %Tc values
  
for i=1:6
    ur5.links(i).I = inertia_data(:,:,i); % link inertia matrix
    ur5.links(i).Jm = Jm_values(i); % Motor inertia
    ur5.links(i).Tc = Tc_values(i);
    ur5.links(i).G=100; % reduction gear ratio
   % ur5.links(i).Bm= 1e-2; 
end


%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Harmonic drives paramiters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Gear ratio
N = 100;

% HFUS25-2UH Paramiters
HFUS25.J = 1.07e-4;
HFUS25.Tr = 157;       % Repeated peak torque
HFUS25.Ta = 108;       % Average torque
HFUS25.T1 = 14;
HFUS25.T2 = 48;
HFUS25.K3 = 57e3;
HFUS25.K2 = 50e3;
HFUS25.K1 = 31e3;

% HFUS14-2UH Paramiters
HFUS14.J = 0.091e-4;
HFUS14.Tr = 28;       % Repeated peak torque
HFUS14.Ta = 11;       % Average torque
HFUS14.T1 = 2;
HFUS14.T2 = 6.9;
HFUS14.K3 = 7.1e3;
HFUS14.K2 = 6.1e3;
HFUS14.K1 = 4.7e3;


%%%%%%%%%%%%%%%%%%%%%%%%
%% Controllers Paramiters
%%%%%%%%%%%%%%%%%%%%%%%%

% PID controller
Kp = 40000;
Kd = 10;
Ki = 2000;



% LQR controller
B = 0.00064;
Jm = 0.091e-4;%
Jl = 0.01;
K = 4700;

A_c = [0 1 0 0; -K/Jl -B/Jl K/(Jl*N) 0; 0 0 0 1; K/(Jm*N) 0 -K/(Jm*N*N) -B/Jm];
B_c = [0 0 0 1/Jm]';
C_c = [1 0 0 0];


Q = [1 0 0 0; 0 0 0 0; 0 0 0 0; 0 0 0 0];
R = 1;

K_lqr = lqr(A_c, B_c, Q, R);

%%%%%%%%%%%%%%%%%%%
%% Target Trajectory
%%%%%%%%%%%%%%%%%%%

% Definition of the trajectory of the UR5 robot.
% Starting with the desired joint positions (qn),
% we calculate the joint trajectory, and then determine
% the position in the operating space (x_traj). 
% The traj_visual matrix contains the spatial coordinates 
% of the points on the trajectory.


T = 5; % total time of the trajectory
res = 100; % number of points sampled for the trajectory

% Definition of the JOINT TRAJECTORY
% Trajectory 1: 
%qn = [pi/2 -pi/2 0 0 0 pi/2];% vector containing the desired positions of the joints.
%Trajectory 2: (more complex)
qn = [pi/4 -3*pi/4 pi/6 0 pi/6 pi/2];

figure
ur5.plot(qn); % To visualize the desired final position
title('Final position');

[q_traj,~,~] = jtraj(qz,qn,res); % Calculates the joint trajectory from
% an initial position (qz) to the desired position (qn). qz corresponds to
% the zero joint angle configuration
q_desired = timeseries(q_traj,linspace(0, T, length(q_traj))); % time series of joint values on the trajectory.

% Calculation of the trajectory in the WORKSPACE
x_traj = ur5.fkine(q_traj);

% matrix that stores the coordinates (X, Y, Z) of the points on the trajectory in the operational space.
traj_visual = zeros(length(x_traj), 3);
for i=1:length(x_traj)
    traj_visual(i, :) = (x_traj(i).t)';
end

% Desired trajectory visualization
if true
    figure
    plot3(traj_visual(:, 1), traj_visual(:, 2), traj_visual(:, 3), 'g', 'LineWidth', 2, 'DisplayName', 'Desired Trajectory');

    hold on;
    % Mark the initial and final points
    scatter3(traj_visual(1,1), traj_visual(1, 2), traj_visual(1,3), 90, 'b', 'filled', 'DisplayName', 'Initial Point');
    scatter3(traj_visual(end, 1), traj_visual(end, 2), traj_visual(end, 3), 150, 'r', 'filled', 'DisplayName', 'Final Point', 'Marker', 'p');

    grid on;
    hold off;
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    title('Workspace Desired Trajectory');
    legend('show')
end

%ur5.links(1).dyn
%M = ur5.inertia(qn)




